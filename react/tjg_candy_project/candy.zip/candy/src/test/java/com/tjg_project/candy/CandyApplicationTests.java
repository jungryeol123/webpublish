package com.tjg_project.candy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandyApplicationTests {

	@Test
	void contextLoads() {
	}

}
